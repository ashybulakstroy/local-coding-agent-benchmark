# Run all Ollama models
python src/agent_model_tester.py --all-models

# Run selected models
# python src/agent_model_tester.py --models qwen2.5-coder:7b deepseek-coder:6.7b

# Run with project path
# python src/agent_model_tester.py --all-models --project-path D:\Projects\your-project
