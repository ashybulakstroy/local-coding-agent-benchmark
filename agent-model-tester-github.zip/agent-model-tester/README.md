# Agent Model Tester

`agent-model-tester` — это простой Python-проект для проверки `agent-compatible` поведения локальных Ollama coding-моделей.

Скрипт не управляет напрямую Cursor/Cline. Он проверяет, насколько модель готова работать как coding agent:

- не выдумывает чтение файлов;
- понимает порядок действий агента;
- упоминает чтение файлов, поиск README и dependency-файлов;
- понимает diff, terminal, test loop и approval;
- не заявляет, что уже выполнила действия без реального доступа к файлам или терминалу.

## Структура проекта

```text
agent-model-tester/
  README.md
  .gitignore
  requirements.txt
  src/
    agent_model_tester.py
```

## Требования

- Python 3.9+
- Установленная и запущенная Ollama
- Загруженные локальные модели

Проверить модели можно командой:

```powershell
ollama list
```

Если Ollama не запущена, запусти:

```powershell
ollama serve
```

## Быстрый запуск

Из корня проекта:

```powershell
python src/agent_model_tester.py --all-models
```

Запуск только выбранных моделей:

```powershell
python src/agent_model_tester.py --models qwen2.5-coder:7b deepseek-coder:6.7b
```

Запуск с указанием пути к проекту:

```powershell
python src/agent_model_tester.py --all-models --project-path D:\Projects\your-project
```

Показать список моделей из Ollama без запуска тестов:

```powershell
python src/agent_model_tester.py --all-models --list-models
```

## Выходные файлы

Скрипт сохраняет результаты в старую согласованную схему:

```text
model_performance_test.log
model_benchmark_ai_report.md
```

### `model_performance_test.log`

Технический лог. В нём хранится:

- `RUN_ID`
- `PROMPT_ID`
- имя модели
- ID теста
- полный prompt
- полный сырой ответ модели
- оценка по проверкам
- ошибки
- время выполнения

### `model_benchmark_ai_report.md`

Человекочитаемый отчет. В нём хранится:

- итоговая таблица по моделям;
- статус `PASSED`, `WARNING`, `FAILED`, `ERROR`;
- баллы;
- среднее время;
- время каждого agent-теста;
- краткие фрагменты ответов;
- причины оценки.

Формат времени в отчете:

```text
Avg 12.34s [ 10.20s / 13.50s / 8.90s / 16.77s ]
```

Порядок цифр указывается один раз выше таблицы:

```text
[ 1. project_scan / 2. write_diff / 3. terminal / 4. repair_loop ]
```

## Agent-compatible тесты

Каждая модель проходит 4 теста:

1. `agent_project_scan_protocol`

   Проверяет, понимает ли модель порядок изучения проекта: структура файлов, README.md, dependency-файлы, точка входа, команды тестов.

2. `agent_write_diff_protocol`

   Проверяет, понимает ли модель работу с изменением файла и diff.

3. `agent_terminal_safety_protocol`

   Проверяет безопасную работу с терминалом и запрет опасных команд.

4. `agent_test_repair_loop_protocol`

   Проверяет полный цикл агента: найти тесты, запустить, объяснить ошибку, предложить минимальное исправление, дождаться подтверждения, показать diff, повторно запустить тесты.

## Примеры команд

Очистить старый Markdown-отчет перед новым запуском:

```powershell
python src/agent_model_tester.py --all-models --clear-report
```

Увеличить timeout:

```powershell
python src/agent_model_tester.py --all-models --timeout 300
```

Ограничить количество моделей при `--all-models`:

```powershell
python src/agent_model_tester.py --all-models --max-models 5
```

Изменить адрес Ollama:

```powershell
python src/agent_model_tester.py --all-models --ollama-url http://localhost:11434
```

## Важное ограничение

Этот проект проверяет модель напрямую через Ollama API:

```text
Python script → Ollama model → raw response → evaluator → report
```

Он не является полной заменой реального теста в Cursor/Cline:

```text
Cline → Ollama model → tool requests → file read/write → terminal → diff
```

Правильный порядок работы:

```text
1. Прогнать все локальные модели через agent_model_tester.py.
2. Выбрать лучшие модели по отчету.
3. Проверить их вручную или полуавтоматически в Cursor + Cline.
4. Только потом давать большие coding-agent задачи.
```

## Рекомендуемый GitHub workflow

```powershell
git init
git add .
git commit -m "Initial agent model tester"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/agent-model-tester.git
git push -u origin main
```

## Лицензия

Добавь нужную лицензию отдельно, если проект будет публичным.
