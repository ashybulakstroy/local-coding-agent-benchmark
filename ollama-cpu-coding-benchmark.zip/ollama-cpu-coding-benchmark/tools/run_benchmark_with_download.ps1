<#
run_benchmark_with_download.ps1

PowerShell-wrapper для красивой загрузки моделей через обычный `ollama pull`,
а затем запуска Python benchmark collector v10 без внутренней загрузки.

Примеры:
  .\run_benchmark_with_download.ps1
  .\run_benchmark_with_download.ps1 -NoDownload
  .\run_benchmark_with_download.ps1 -PullSet quick
  .\run_benchmark_with_download.ps1 -PullSet cpu -Full
  .\run_benchmark_with_download.ps1 -Model qwen2.5-coder:3b -Model codegemma:2b
  .\run_benchmark_with_download.ps1 -NoDownload -Model qwen2.5-coder:3b -RerunExisting
#>

[CmdletBinding()]
param(
    [string[]]$Model,

    [ValidateSet("installed", "quick", "cpu", "heavy", "all")]
    [string]$PullSet = "installed",

    [switch]$Full,
    [switch]$NoDownload,
    [switch]$RerunExisting,
    [int]$MaxAttempts = 3,

    [string]$PythonScript = ".\model_performance_test.py",

    [int]$NumCtx = 2048,
    [int]$NumPredict = 1200,
    [double]$Temperature = 0.1,
    [int]$TimeoutSeconds = 900
)

$ErrorActionPreference = "Stop"

$ModelSets = @{
    quick = @(
        "qwen2.5-coder:1.5b",
        "qwen2.5-coder:3b",
        "codegemma:2b",
        "deepseek-coder:1.3b"
    )
    cpu = @(
        "qwen2.5-coder:1.5b",
        "qwen2.5-coder:3b",
        "codegemma:2b",
        "deepseek-coder:1.3b",
        "starcoder2:3b",
        "granite-code:3b",
        "stable-code:3b",
        "yi-coder:1.5b"
    )
    heavy = @(
        "qwen2.5-coder:7b",
        "deepseek-coder:6.7b",
        "mistral:7b-instruct-v0.3",
        "codellama:7b-instruct"
    )
}
$ModelSets.all = @($ModelSets.cpu + $ModelSets.heavy + @("llama3.2:3b", "phi3:mini") | Select-Object -Unique)

function Write-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host "==== $Message ====" -ForegroundColor Cyan
}

function Test-CommandExists {
    param([string]$Name)
    return [bool](Get-Command $Name -ErrorAction SilentlyContinue)
}

function Pull-ModelInteractive {
    param(
        [string]$ModelName,
        [int]$Attempts
    )

    for ($i = 1; $i -le $Attempts; $i++) {
        Write-Host ""
        Write-Host "Модель: $ModelName | попытка $i из $Attempts" -ForegroundColor Yellow
        Write-Host "Сейчас будет обычный интерактивный прогресс Ollama..." -ForegroundColor DarkGray

        & ollama pull $ModelName
        $exitCode = $LASTEXITCODE

        if ($exitCode -eq 0) {
            Write-Host "OK: $ModelName скачана/проверена" -ForegroundColor Green
            return $true
        }

        Write-Host "ОШИБКА: $ModelName | код выхода: $exitCode" -ForegroundColor Red

        if ($i -lt $Attempts) {
            Write-Host "Пробую удалить возможную битую запись модели и скачать заново..." -ForegroundColor DarkYellow
            & ollama rm $ModelName 2>$null
            Start-Sleep -Seconds 5
        }
    }

    Write-Host "FAILED: $ModelName не скачалась после $Attempts попыток" -ForegroundColor Red
    return $false
}

function Resolve-PythonRunner {
    if (Test-CommandExists "py") {
        return "py"
    }
    if (Test-CommandExists "python") {
        return "python"
    }
    throw "Python runner not found. Install Python and make sure 'py' or 'python' is available."
}

if (-not (Test-CommandExists "ollama")) {
    throw "Ollama command not found. Install Ollama or restart PowerShell so PATH is refreshed."
}

if (-not (Test-Path $PythonScript)) {
    throw "Python benchmark script not found: $PythonScript"
}

$UseInstalledFromOllama = $false

if ($Model -and $Model.Count -gt 0) {
    $SelectedModels = @($Model | Select-Object -Unique)
} elseif ($PullSet -eq "installed") {
    $SelectedModels = @()
    $UseInstalledFromOllama = $true
} else {
    $SelectedModels = @($ModelSets[$PullSet] | Select-Object -Unique)
}

Write-Step "Ollama benchmark wrapper"
if ($UseInstalledFromOllama) { Write-Host "Models count: all installed models from Ollama" } else { Write-Host "Models count: $($SelectedModels.Count)" }
Write-Host "PullSet: $PullSet"
Write-Host "NoDownload: $NoDownload"
Write-Host "Full: $Full"
Write-Host "PythonScript: $PythonScript"
Write-Host "NumCtx: $NumCtx"
Write-Host "NumPredict: $NumPredict"
Write-Host "Temperature: $Temperature"
Write-Host "TimeoutSeconds: $TimeoutSeconds"

$ModelsForTest = @()

if ($UseInstalledFromOllama) {
    Write-Step "Модели будут взяты напрямую из Ollama"
    Write-Host "Wrapper не передаёт список --model. Python сам выполнит /api/tags и протестирует все установленные модели." -ForegroundColor DarkGray
} elseif ($NoDownload) {
    Write-Step "Загрузка пропущена"
    $ModelsForTest = $SelectedModels
} else {
    Write-Step "Загрузка моделей"
    $index = 0
    foreach ($m in $SelectedModels) {
        $index++
        Write-Host ""
        Write-Host "[$index/$($SelectedModels.Count)] Подготовка модели: $m" -ForegroundColor Cyan
        $ok = Pull-ModelInteractive -ModelName $m -Attempts $MaxAttempts
        if ($ok) {
            $ModelsForTest += $m
        }
    }

    if ($ModelsForTest.Count -eq 0) {
        throw "Нет успешно скачанных моделей. Тестирование отменено."
    }
}

Write-Step "Запуск benchmark без внутренней загрузки"

$PythonRunner = Resolve-PythonRunner
$ArgsList = @()
$ArgsList += $PythonScript
$ArgsList += "--no-pull"
$ArgsList += "--num-ctx"
$ArgsList += "$NumCtx"
$ArgsList += "--num-predict"
$ArgsList += "$NumPredict"
$ArgsList += "--temperature"
$ArgsList += "$Temperature"
$ArgsList += "--timeout-seconds"
$ArgsList += "$TimeoutSeconds"

if ($UseInstalledFromOllama) {
    $ArgsList += "--model-source"
    $ArgsList += "installed"
} else {
    foreach ($m in $ModelsForTest) {
        $ArgsList += "--model"
        $ArgsList += $m
    }
}

if ($Full) {
    $ArgsList += "--full"
}

if ($RerunExisting) {
    $ArgsList += "--rerun-existing"
}

Write-Host "Команда:" -ForegroundColor DarkGray
Write-Host "$PythonRunner $($ArgsList -join ' ')" -ForegroundColor DarkGray

& $PythonRunner @ArgsList
$exitCode = $LASTEXITCODE

Write-Step "Готово"
Write-Host "Python benchmark exit code: $exitCode"
exit $exitCode
